package dev.pixelove.controlcenter

import android.app.Activity
import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(34), dp(24), dp(24)); setBackgroundColor(0xff101116.toInt()) }
        fun text(s: String, size: Float, color: Int = 0xffffffff.toInt()) = TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0, dp(8), 0, dp(8)) }
        root.addView(text("Control Center", 30f))
        root.addView(text("Non-root edition • Android 12+", 15f, 0xffb7b8c3.toInt()))
        root.addView(text("Setup", 20f))
        root.addView(text("1. Enable the accessibility service so the floating handle can appear over other apps.\n2. Grant Modify system settings for brightness control.\n3. Camera permission is optional and only used for the flashlight.", 15f, 0xffd0d1da.toInt()))
        fun button(label: String, action: () -> Unit) {
            val b = Button(this).apply { text=label; isAllCaps=false; setOnClickListener { action() } }
            root.addView(b, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin=dp(8) })
        }
        button("Enable accessibility service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("Allow modify system settings") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        button("Allow draw over other apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        button("Grant camera permission (flashlight)") { if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.CAMERA), 22) else android.widget.Toast.makeText(this, "Camera permission already granted", android.widget.Toast.LENGTH_SHORT).show() }
        button("Open app settings / permissions") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        button("Open Android quick settings") { startActivity(Intent(Settings.ACTION_QUICK_SETTINGS)) }
        root.addView(text("The floating handle appears after the accessibility service is enabled. Drag it to reposition it, then tap it to open the panel.", 13f, 0xff9da0ad.toInt()))
        setContentView(root)
    }
}
