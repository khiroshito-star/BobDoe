# Control Center Non-Root (Android 12+)

An independent non-root recreation of the Control Center concept in the supplied `ControlCenter-2.24.apk` reference. The reference APK identifies itself as an Xposed module (`assets/xposed_init` and Xposed metadata/strings), so its System UI hooks cannot simply be made non-root by changing the manifest. This project implements a separate app using Android's supported AccessibilityService overlay APIs.

## Build

- Android Studio: open this folder, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
- GitHub: push the repository and use the included **Build Android APK** workflow. The debug APK is uploaded as a workflow artifact.
- Minimum Android: 12 / API 31. Compile/target: API 35.

## Setup on device

1. Install the APK.
2. Open the app and tap **Enable accessibility service**. Enable Control Center accessibility in Android Settings.
3. Grant **Modify system settings** for brightness control.
4. Camera permission may be needed by Android before flashlight access; grant it through App info if prompted.
5. A small floating handle appears. Drag it to reposition, tap to open/close the panel.

## Available features

- Floating handle and overlay panel above other apps via AccessibilityService.
- Brightness slider (requires Modify system settings).
- Media volume slider.
- Flashlight toggle where device hardware and permission allow it.
- Screenshot, Home, Back, and Recents via accessibility global actions.
- Wi-Fi and Bluetooth launch Android's system panels/settings; airplane mode, DND, battery and display launch system settings.

## Android restrictions (not bugs)

A normal app cannot silently toggle protected radios/settings such as Wi-Fi, Bluetooth, airplane mode, mobile data, or grant itself permissions on modern Android. Those controls are routed to Android system panels/settings. Accessibility is not root and does not grant kernel/SystemUI privileges. The app does not claim to provide unrestricted access to protected system functions.

## Reference APK and source status

The supplied APK is a compiled binary, not an Android Studio project. Its original Java/Kotlin source cannot be copied verbatim from the APK as source code; the included app is a clean independent implementation of a similar control-center experience. The uploaded SF Pro font is included in `app/src/main/assets/SF-Pro.ttf` for future UI styling; current views use Android's default typeface.
